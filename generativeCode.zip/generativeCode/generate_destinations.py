import csv
import random
from faker import Faker

def generate_meaningful_description(name, category_code, district):
    """
    Sinh mô tả dựa trên mã danh mục (category_code) mới.
    """
    category_definitions = {
        "mua_sam": "là không gian giao thương sầm uất, nơi hội tụ đa dạng các mặt hàng và đặc sản",
        "du_lich_song_ao": "sở hữu không gian kiến trúc độc đáo, là điểm đến lý tưởng để lưu lại những bức ảnh tuyệt đẹp",
        "tam_linh": "là công trình kiến trúc gắn liền với tín ngưỡng, phục vụ nhu cầu hành hương và tìm kiếm sự tĩnh tại",
        "am_thuc": "mang đến trải nghiệm ẩm thực đa dạng với những món ăn đậm đà hương vị bản địa",
        "giai_tri": "là tổ hợp các hoạt động vui chơi giải trí, thiết kế chuyên biệt để mang lại năng lượng tích cực",
        "nghi_duong": "cung cấp không gian thư giãn tuyệt vời, giúp du khách phục hồi năng lượng và tận hưởng cuộc sống",
        "lich_su": "mang đậm dấu ấn thời gian, lưu giữ các giá trị văn hóa và sự kiện quan trọng của thành phố",
        "thien_nhien": "được bao phủ bởi mảng xanh tươi mát, mang đến bầu không khí trong lành và thư thái"
    }

    # Lấy định nghĩa dựa trên mã category, mặc định nếu không khớp
    definition = category_definitions.get(category_code, "mang lại những trải nghiệm độc đáo cho khách tham quan")

    # Bỏ phần đuôi ", Quận X" ra khỏi tên khi đưa vào câu mô tả cho tự nhiên
    clean_name = name.split(',')[0]

    templates = [
        f"Tọa lạc tại {district}, {clean_name} {definition}. Đây là một điểm đến thu hút rất nhiều người dân và du khách.",
        f"{clean_name} là một địa điểm nổi bật. Nơi đây {definition}, góp phần làm phong phú thêm nhịp sống tại TP.HCM.",
        f"Được biết đến như một biểu tượng quen thuộc tại {district}, {clean_name} {definition}."
    ]

    return random.choice(templates)


# Khởi tạo Faker
fake = Faker('vi_VN')

# Tọa độ giới hạn TP.HCM
HCM_LAT_MIN, HCM_LAT_MAX = 10.370000, 11.140000
HCM_LNG_MIN, HCM_LNG_MAX = 106.350000, 106.930000

# Danh sách quận huyện
HCM_DISTRICTS = [
    "Quận 1", "Quận 3", "Quận 4", "Quận 5", "Quận 6", "Quận 7", "Quận 8", 
    "Quận 10", "Quận 11", "Quận 12", "Bình Thạnh", "Phú Nhuận", 
    "Gò Vấp", "Tân Bình", "Tân Phú", "Bình Tân", 
    "TP. Thủ Đức", "Huyện Bình Chánh", "Huyện Hóc Môn", "Huyện Củ Chi", 
    "Huyện Nhà Bè", "Huyện Cần Giờ"
]

# Danh mục được chuyển sang dạng mã (snake_case) như yêu cầu
CATEGORY_CODES = [
    "mua_sam", "du_lich_song_ao", "tam_linh", "am_thuc", 
    "giai_tri", "nghi_duong", "lich_su", "thien_nhien"
]

NAME_PREFIXES = ["Khu du lịch", "Bảo tàng", "Công viên", "Nhà hàng", "Tiệm cafe", "Chợ", "Tổ hợp", "Phố"]

def generate_hcm_destinations(num_records=500, filename='./SampleData/destinations.csv'):
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow([
            'destination_id', 'name', 'category', 'address', 
            'latitude', 'longitude', 'description', 'rating_avg', 
            'is_active', 'created_at', 'last_updated_at'
        ])
        
        for i in range(1, num_records + 1):
            dest_id = f"DST_{i:06d}"
            category = random.choice(CATEGORY_CODES)
            district = random.choice(HCM_DISTRICTS)
            name = f"Địa điểm {fake.first_name()}, {district}"
            address = f"{fake.street_address()}, {district}, TP. Hồ Chí Minh"
            description = generate_meaningful_description(name, category, district)
            latitude = round(random.uniform(HCM_LAT_MIN, HCM_LAT_MAX), 6)
            longitude = round(random.uniform(HCM_LNG_MIN, HCM_LNG_MAX), 6)
            rating_avg = round(random.uniform(3.5, 5.0), 2)
            
            created_at = fake.date_time_between(start_date='-2y', end_date='-6m')
            last_updated_at = fake.date_time_between(start_date=created_at, end_date='now')
            
            writer.writerow([
                dest_id, name, category, address, latitude, longitude,
                description, rating_avg, True, 
                f"{created_at.strftime('%Y-%m-%d %H:%M:%S')}+07", 
                f"{last_updated_at.strftime('%Y-%m-%d %H:%M:%S')}+07"
            ])

if __name__ == "__main__":
    generate_hcm_destinations()