import csv
import random
import os
from datetime import datetime, timedelta

# --- 1. TỪ ĐIỂN BÌNH LUẬN CHO CHUYẾN ĐI (TRIPS) ---
TRIP_COMMENTS = {
    5: ["Chuyến đi quá tuyệt vời!", "Mọi thứ diễn ra rất suôn sẻ, trên cả mong đợi.", "Lịch trình hợp lý, rất đáng nhớ.", "Trải nghiệm xuất sắc, sẽ đi lại cung đường này!"],
    4: ["Chuyến đi khá ổn, thời tiết đẹp.", "Cơ bản là tốt, chỉ hơi mệt lúc di chuyển.", "Lịch trình ổn định, vui vẻ.", "Đáng đồng tiền bát gạo, nhưng cần chuẩn bị kỹ hơn chút."],
    3: ["Chuyến đi bình thường, không có gì quá nổi bật.", "Điểm đến hơi đông đúc so với kỳ vọng.", "Cũng tạm được, một vài nơi chưa ưng ý lắm."],
    2: ["Lịch trình hơi chán, mệt mỏi.", "Gặp chút sự cố trên đường, không vui lắm.", "Chi phí bị lố so với dự kiến ban đầu, hơi thất vọng."],
    1: ["Thật sự tệ, một chuyến đi đáng quên.", "Trải nghiệm rất kém, mọi thứ đều không như kế hoạch.", "Quá mệt và tốn kém vô ích."]
}

# --- 2. TỪ ĐIỂN BÌNH LUẬN CHO ĐỊA ĐIỂM (DESTINATIONS) ---
DEST_COMMENTS = {
    5: ["Cảnh quan tuyệt đẹp, góc nào chụp cũng đẹp!", "Dịch vụ rất tốt, nhân viên nhiệt tình.", "Đồ ăn ngon tuyệt, nhất định phải thử.", "Rộng rãi, thoáng mát, cực kỳ thư giãn."],
    4: ["Nơi này đẹp, nhưng hơi đông người một chút.", "Cũng khá thú vị, giá cả hợp lý.", "Đồ ăn ngon nhưng đợi hơi lâu.", "Cảnh quan ổn, phù hợp đi cùng gia đình."],
    3: ["Không có gì đặc sắc, giống như trên mạng thôi.", "Giá vé hơi cao so với trải nghiệm.", "Bình thường, đi một lần cho biết."],
    2: ["Chỗ này quá ồn ào và lộn xộn.", "Dịch vụ tệ, nhân viên thái độ không tốt.", "Không giống như hình ảnh quảng cáo, khá thất vọng.", "Đồ ăn dở và đắt."],
    1: ["Tệ hại! Sẽ không bao giờ quay lại đây.", "Chặt chém khách du lịch, mọi người nên tránh.", "Rất dơ bẩn và không được bảo trì.", "Mất tiền oan, chán không tả được."]
}

def generate_reviews_csv(
    trips_file="./SampleData/trips.csv",
    trip_dests_file="./SampleData/trip_destinations.csv", # Thêm dấu chấm để thành đường dẫn tương đối an toàn
    output_file="./SampleData/reviews.csv"
):
    # Kiểm tra file tồn tại
    if not os.path.exists(trips_file) or not os.path.exists(trip_dests_file):
        print("❌ Không tìm thấy file trips hoặc trip_destinations. Vui lòng kiểm tra lại đường dẫn.")
        return

    # Load dữ liệu Trips
    trips_dict = {}
    fmt = '%Y-%m-%d %H:%M:%S+07'
    with open(trips_file, mode='r', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            trips_dict[row['trip_id']] = {
                'user_id': row['user_id'],
                'end_time': datetime.strptime(row['end_time'], fmt)
            }

    # Load dữ liệu Trip Destinations
    trip_destinations = {}
    with open(trip_dests_file, mode='r', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            t_id = row['trip_id']
            if t_id not in trip_destinations:
                trip_destinations[t_id] = []
            trip_destinations[t_id].append({
                'destination_id': row['destination_id'],
                'departure_time': datetime.strptime(row['departure_time'], fmt)
            })

    # Bắt đầu sinh Review
    with open(output_file, mode='w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile)
        # Đổi last_created_at thành last_update_at để chuẩn hóa database
        writer.writerow(['user_id', 'destination_id', 'rating', 'comment', 'created_at', 'last_update_at'])

        
        
        for trip_id, trip_info in trips_dict.items():
            user_id = trip_info['user_id']
            trip_end = trip_info['end_time']

            # --- LOẠI 1: REVIEW CHUYẾN ĐI ---
            if random.random() < 0.4:
                rating = random.choices([5, 4, 3, 2, 1], weights=[45, 35, 10, 5, 5], k=1)[0]
                comment = random.choice(TRIP_COMMENTS[rating])
                
                # Thời điểm viết review: từ 1 giờ đến 5 ngày sau chuyến đi
                review_time = trip_end + timedelta(hours=random.randint(1, 120))
                
                # Logic Last Update: 15% xác suất người dùng vào sửa lại review
                if random.random() < 0.15:
                    # Chỉnh sửa xảy ra từ 1 giờ đến 3 ngày sau khi viết review
                    last_update_time = review_time + timedelta(hours=random.randint(1, 72))
                else:
                    last_update_time = review_time
                
                writer.writerow([
                    user_id, rating, comment, 
                    review_time.strftime(fmt), 
                    last_update_time.strftime(fmt)
                ])
                

            # --- LOẠI 2: REVIEW ĐỊA ĐIỂM ---
            if trip_id in trip_destinations:
                for dest in trip_destinations[trip_id]:
                    if random.random() < 0.3:
                        rating = random.choices([5, 4, 3, 2, 1], weights=[40, 30, 15, 10, 5], k=1)[0]
                        comment = random.choice(DEST_COMMENTS[rating]) if random.random() > 0.2 else ""
                        
                        # Thời điểm viết review: sau khi rời khỏi địa điểm
                        review_time = dest['departure_time'] + timedelta(hours=random.randint(1, 72))
                        
                        # Logic Last Update: 10% xác suất sửa review địa điểm (thường ít sửa hơn review chuyến đi dài)
                        if random.random() < 0.10:
                            last_update_time = review_time + timedelta(hours=random.randint(1, 24))
                        else:
                            last_update_time = review_time
                        
                        writer.writerow([
                            user_id, dest['destination_id'], rating, comment, 
                            review_time.strftime(fmt), 
                            last_update_time.strftime(fmt)
                        ])
                        

    print(f"✅ Đã tạo thành công lượt reviews!")
    print(f"👉 File được lưu tại: {output_file}")

if __name__ == "__main__":
    generate_reviews_csv()
    