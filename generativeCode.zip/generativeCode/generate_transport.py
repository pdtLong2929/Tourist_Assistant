import csv
import os
from datetime import datetime

# --- CẤU HÌNH ---
BASE_DIR = "./SampleData/"
PROVIDERS_FILE = os.path.join(BASE_DIR, "transport_providers.csv")
MODES_FILE = os.path.join(BASE_DIR, "transport_modes.csv")

PROVIDERS_DATA = [
    {"name": "Grab", "type": "RIDE_HAILING", "api": True, "url": "grab.com/vn"},
    {"name": "Be", "type": "RIDE_HAILING", "api": True, "url": "be.com.vn"},
    {"name": "Gojek", "type": "RIDE_HAILING", "api": True, "url": "gojek.com/vn"},
    {"name": "Xanh SM", "type": "RIDE_HAILING", "api": True, "url": "xanhsm.com"},
    {"name": "Trung tâm QLGTCC TPHCM", "type": "PUBLIC_TRANSPORT", "api": False, "url": "buyttphcm.com.vn"},
    {"name": "Saigon Metro", "type": "PUBLIC_TRANSPORT", "api": False, "url": "maur.hochiminhcity.gov.vn"},
    {"name": "Vinasun Taxi", "type": "RIDE_HAILING", "api": False, "url": "vinasun.vn"},
    {"name": "Thuê xe máy Sài Gòn", "type": "PARTNER_RENTAL", "api": False, "url": ""}
]

MODES_DATA = [
    {"code": "BUS", "name": "Xe buýt"},
    {"code": "METRO", "name": "Tàu điện ngầm"},
    {"code": "TRAIN", "name": "Tàu hỏa"},
    {"code": "WALK", "name": "Đi bộ"},
    {"code": "BIKE", "name": "Xe đạp/Xe máy"},
    {"code": "CAR", "name": "Ô tô cá nhân"},
    {"code": "RIDE_HAILING", "name": "Xe ôm/Taxi công nghệ"}
]

def generate_static_data():
    os.makedirs(BASE_DIR, exist_ok=True)
    fmt = '%Y-%m-%d %H:%M:%S+07'
    now_str = datetime.now().strftime(fmt)

    # --- TẠO BẢNG PROVIDERS ---
    with open(PROVIDERS_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['provider_id', 'name', 'provider_type', 'api_supported', 'website_url', 'is_active', 'created_at', 'last_updated_at'])
        for idx, p in enumerate(PROVIDERS_DATA, 1):
            p_id = f"PRV_{idx:06d}" # ID 10 ký tự
            writer.writerow([p_id, p['name'], p['type'], p['api'], p['url'], True, now_str, now_str])

    # --- TẠO BẢNG MODES ---
    with open(MODES_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['mode_id', 'code', 'name', 'created_at', 'last_updated_at'])
        for idx, m in enumerate(MODES_DATA, 1):
            m_id = f"MOD_{idx:06d}" # ID 10 ký tự
            writer.writerow([m_id, m['code'], m['name'], now_str, now_str])

    print("✅ Đã tạo bảng transport_providers và transport_modes chuẩn Schema.")

if __name__ == "__main__":
    generate_static_data()