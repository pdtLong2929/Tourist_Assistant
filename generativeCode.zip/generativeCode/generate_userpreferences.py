import csv
import random
import json
from faker import Faker
from datetime import timedelta

fake = Faker('vi_VN')

# Định nghĩa các tập dữ liệu thực tế cho hệ thống du lịch
TRANSPORT_MODES = ["BUS","METRO","TRAIN","WALK","BIKE","CAR","RIDE_HAILING"]


FOOD_TAGS = [
    "Hải sản", "Đồ chay", "Đặc sản địa phương", "Món Á", "Món Âu", "Đường phố", 
    "BBQ", "Fine Dining", "Sushi/Sashimi", "Pizza/Pasta", "Steakhouse", "Dimsum", 
    "Lẩu Thái", "Cơm niêu", "Món Huế", "Thực phẩm Keto", "Đồ ngọt/Bakery", 
    "Món nướng ngói", "Buffet hải sản", "Món nhậu/Pub food", "Burger/Sandwich", 
    "Món chay thực dưỡng", "Món Hàn Quốc", "Món Thái Lan", "Món Ấn Độ", 
    "Salad bar", "Fusion Cuisine", "Món ăn từ nấm", "Đặc sản Tây Nguyên", 
    "Đặc sản Tây Bắc", "Trà sữa/Café", "Trái cây nhiệt đới"
]

DESTINATION_TAGS = [
    "Biển", "Núi", "Thành phố", "Lịch sử", "Thiên nhiên", "Nghỉ dưỡng", 
    "Phiêu lưu", "Văn hóa", "Tâm linh", "Đảo nhỏ", "Hang động", "Thác nước", 
    "Cao nguyên", "Rừng quốc gia", "Suối khoáng nóng", "Làng cổ", "Phố đi bộ", 
    "Khu vui chơi", "Safari", "Bảo tàng nghệ thuật", "Di sản UNESCO", "Glamping", 
    "Vườn hoa/Đồng cỏ", "Khu kinh tế đêm", "Trang trại/Agritourism", "Vùng vịnh", 
    "Cung điện/Lăng tẩm", "Đô thị hiện đại", "Làng chài", "Đồi chè/Cà phê", 
    "Sân Golf", "Đài quan sát"
]

AVOID_TAGS = [
    "Đông đúc", "Nắng nóng", "Leo núi", "Say xe", "Quá lạnh", "Trẻ em ồn ào", 
    "Côn trùng", "Khói bụi", "Ô nhiễm tiếng ồn", "Vệ sinh kém", "Chặt chém giá", 
    "Đường gập ghềnh", "Đồ ăn quá cay", "Thiếu Wifi", "Sợ độ cao", "Đi bộ quá nhiều", 
    "Mùi nồng/lạ", "Khu vực hẻo lánh", "Không có thang máy", "Thời tiết ẩm ướt", 
    "Đắt đỏ/Xa xỉ", "Hàng rong chèo kéo", "Không gian kín", "Thủ tục visa phức tạp", 
    "Ánh sáng quá gắt", "Nhạc quá to", "Thiếu nước sạch", "Vùng có trộm cắp", 
    "Đồ ăn sống", "Dị ứng hải sản", "Không được mang thú cưng", "Cấm quay phim/chụp ảnh"
]

def generate_preferences_csv(filename="./SampleData/user_preferences.csv", total_users=1000):
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow([
            'user_id', 'preferred_transport_modes', 'budget_min', 'budget_max', 
            'preferred_food_tags', 'preferred_destination_tags', 'avoid_tags', 
            'created_at', 'last_updated_at'
        ])

        for i in range(1, total_users + 1):
            user_id = f"USR_{i:06d}" # Khớp với bảng users
            
            transports = random.sample(TRANSPORT_MODES, k=random.randint(1, 3))
            foods = random.sample(FOOD_TAGS, k=random.randint(1, 3))
            destinations = random.sample(DESTINATION_TAGS, k=random.randint(1, 3))
            avoids = random.sample(AVOID_TAGS, k=random.randint(1, 2)) if random.random() > 0.4 else []

            b_min = random.randint(2, 10) * 1000000 
            b_max = b_min + (random.randint(2, 20) * 1000000)

            created_at = fake.date_time_between(start_date='-1y', end_date='now')
            updated_at = created_at + timedelta(days=random.randint(0, 30)) if random.random() > 0.5 else created_at

            writer.writerow([
                user_id, 
                json.dumps(transports, ensure_ascii=False), 
                f"{b_min:.2f}", f"{b_max:.2f}", 
                json.dumps(foods, ensure_ascii=False), 
                json.dumps(destinations, ensure_ascii=False), 
                json.dumps(avoids, ensure_ascii=False), 
                created_at.strftime('%Y-%m-%d %H:%M:%S+07'), 
                updated_at.strftime('%Y-%m-%d %H:%M:%S+07')
            ])

if __name__ == "__main__":
    generate_preferences_csv()