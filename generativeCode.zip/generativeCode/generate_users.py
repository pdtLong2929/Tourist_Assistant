import csv
import random
import unicodedata
import re
from faker import Faker
from datetime import timedelta

fake_vi = Faker('vi_VN')
fake_en = Faker('en_US')

auth_providers = ['local', 'google']
provider_weights = [0.6, 0.4]
domains = ['gmail.com', 'yahoo.com', 'outlook.com', 'icloud.com']
PLAIN_PASSWORD = "123456"
generated_emails = set()

def remove_accents(input_str):
    s = unicodedata.normalize('NFD', input_str).encode('ascii', 'ignore').decode("utf-8")
    return re.sub(r'[^a-z0-9\s]', '', s.lower())

def create_realistic_email(full_name):
    clean_name = remove_accents(full_name)
    parts = clean_name.split()
    first_name = parts[-1] if parts else "user"
    last_name = parts[0] if len(parts) > 1 else ""
    domain = random.choice(domains)
    
    base_email = f"{first_name}.{last_name}{random.randint(80,99)}@{domain}"
    final_email = base_email
    counter = 1
    while final_email in generated_emails:
        final_email = f"{first_name}.{last_name}{counter}@{domain}"
        counter += 1
    generated_emails.add(final_email)
    return final_email

def generate_users_csv(filename="./SampleData/users.csv", total_records=1000):
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['user_id', 'full_name', 'email', 'phone', 'password_hash', 'auth_provider', 'created_at', 'last_updated_at'])

        for i in range(1, total_records + 1):
            user_id = f"USR_{i:06d}" # Định dạng đúng 10 ký tự character(10)
            
            fake = fake_vi if random.random() < 0.7 else fake_en
            full_name = fake.name()
            email = create_realistic_email(full_name)
            phone = f"{random.choice(['03', '05', '07', '08', '09'])}{fake.unique.numerify('########')}"
            
            auth_provider = random.choices(auth_providers, weights=provider_weights, k=1)[0]
            password_value = PLAIN_PASSWORD if auth_provider == 'local' else ""

            created_at = fake.date_time_between(start_date='-2y', end_date='now')
            updated_at = created_at + timedelta(days=random.randint(0, 60)) if random.random() > 0.5 else created_at
            
            writer.writerow([
                user_id, full_name, email, phone, password_value, auth_provider, 
                created_at.strftime('%Y-%m-%d %H:%M:%S+07'), 
                updated_at.strftime('%Y-%m-%d %H:%M:%S+07')
            ])

if __name__ == "__main__":
    import os
    os.makedirs("./SampleData", exist_ok=True)
    generate_users_csv()