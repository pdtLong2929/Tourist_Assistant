import csv
import random
from faker import Faker
from datetime import timedelta

fake = Faker('vi_VN')

# Tập dữ liệu địa điểm nội thành TP.HCM (Chiếm đa số)
HCMC_LOCATIONS = [
    # Biểu tượng & Du lịch
    "Chợ Bến Thành, Quận 1", "Phố đi bộ Nguyễn Huệ, Quận 1", "Landmark 81, Bình Thạnh",
    "Nhà thờ Đức Bà, Quận 1", "Bưu điện Trung tâm Sài Gòn", "Dinh Độc Lập, Quận 1",
    "Bitexco Financial Tower, Quận 1", "Bến Bạch Đằng, Quận 1", "Hồ Con Rùa, Quận 3",
    "Phố Tây Bùi Viện, Quận 1", "Bảo tàng Chứng tích Chiến tranh, Quận 3", "Bảo tàng Mỹ thuật TP.HCM",
    
    # Trung tâm thương mại & Giải trí
    "Crescent Mall, Quận 7", "Hồ Bán Nguyệt, Quận 7", "SC VivoCity, Quận 7",
    "Takashimaya, Quận 1", "Vincom Center Đồng Khởi", "Vạn Hạnh Mall, Quận 10",
    "Aeon Mall Tân Phú", "Aeon Mall Bình Tân", "Giga Mall, TP. Thủ Đức", "Estella Place, TP. Thủ Đức",
    "Khu du lịch Suối Tiên, TP. Thủ Đức", "Công viên Đầm Sen, Quận 11", "Thảo Cầm Viên, Quận 1",
    "Khu du lịch Bình Quới, Bình Thạnh", "Khu du lịch Văn Thánh, Bình Thạnh",
    
    # Chợ & Phố ẩm thực
    "Chợ Lớn (Chợ Bình Tây), Quận 5", "Chợ An Đông, Quận 5", "Chợ Tân Định, Quận 1",
    "Chợ Bà Chiểu, Bình Thạnh", "Chợ Hạnh Thông Tây, Gò Vấp", "Phố ẩm thực Phan Xích Long, Phú Nhuận",
    "Khu Tên Lửa, Bình Tân", "Phố lẩu dê Hồ Thị Kỷ, Quận 10", "Chợ hoa Hồ Thị Kỷ",

    # Trường Đại học (Đi học, đi làm đồ án)
    "Trường Đại học Khoa học Tự nhiên, Quận 5", "Trường Đại học Khoa học Tự nhiên - Cơ sở Linh Trung", 
    "Làng Đại học Quốc gia, TP. Thủ Đức", "Đại học Bách Khoa TP.HCM, Quận 10",
    "Đại học RMIT, Quận 7", "Đại học Tôn Đức Thắng, Quận 7", "Đại học Kinh tế TP.HCM, Quận 3",
    "Đại học Ngoại thương Cơ sở 2, Bình Thạnh", "Hutech, Bình Thạnh",

    # Giao thông trọng điểm & Bệnh viện
    "Sân bay Tân Sơn Nhất, Tân Bình", "Bến xe Miền Đông (Mới), TP. Thủ Đức", 
    "Bến xe Miền Tây, Bình Tân", "Ga Sài Gòn, Quận 3", "Bến xe An Sương, Hóc Môn",
    "Bệnh viện Chợ Rẫy, Quận 5", "Bệnh viện Đại học Y Dược, Quận 5", 
    "Bệnh viện Nhi Đồng 1, Quận 10", "Bệnh viện Từ Dũ, Quận 1",

    # Công viên & Tâm linh
    "Công viên Lê Văn Tám, Quận 1", "Công viên Hoàng Văn Thụ, Tân Bình", 
    "Công viên Gia Định, Gò Vấp", "Chùa Ngọc Hoàng, Quận 1", "Chùa Bửu Long, TP. Thủ Đức",
    "Việt Nam Quốc Tự, Quận 10", "Chùa Vĩnh Nghiêm, Quận 3"
]

# Tập dữ liệu địa điểm lân cận TP.HCM (Phù hợp di chuyển dưới 3 tiếng)
OTHER_LOCATIONS = [
    # Bình Dương (Sát vách TP.HCM)
    "Ga Dĩ An, Bình Dương", "Khu công nghiệp Sóng Thần, Dĩ An", "Khu du lịch Thủy Châu, Dĩ An",
    "Aeon Mall Bình Dương Canary", "Làng tre Phú An, Bình Dương", "Khu du lịch Đại Nam, Bình Dương", 
    "Chùa Bà Thiên Hậu, Thủ Dầu Một", "Hồ Đá, Dĩ An",
    
    # Đồng Nai & Vũng Tàu (Hướng Đông)
    "Khu du lịch Bửu Long, Đồng Nai", "Thác Giang Điền, Đồng Nai", "Hồ Trị An, Đồng Nai",
    "Vườn quốc gia Cát Tiên, Đồng Nai", "Vườn ca cao Trọng Đức, Định Quán",
    "Bãi Sau, TP. Vũng Tàu", "Bãi Trước, TP. Vũng Tàu", "Tượng Chúa Dang Tay, Vũng Tàu",
    "Mũi Nghinh Phong, Vũng Tàu", "Ngọn hải đăng Vũng Tàu", "Hồ Tràm, Bà Rịa - Vũng Tàu",
    "Biển Long Hải, Bà Rịa", "Đảo Long Sơn, Bà Rịa",
    
    # Tây Ninh & Củ Chi/Cần Giờ
    "Núi Bà Đen, Tây Ninh", "Toà thánh Tây Ninh", "Hồ Dầu Tiếng, Tây Ninh", 
    "Cửa khẩu Mộc Bài, Tây Ninh", "Địa đạo Củ Chi, TP.HCM", "Biển Cần Giờ, TP.HCM",
    "Đảo Khỉ Cần Giờ, TP.HCM",
    
    # Miền Tây lân cận (Hướng Tây Nam)
    "Làng nổi Tân Lập, Long An", "Cánh đồng bất tận, Long An", "Bến Ninh Kiều, Cần Thơ", 
    "Chợ nổi Cái Răng, Cần Thơ", "Cồn Thới Sơn, Tiền Giang", "Trại rắn Đồng Tâm, Tiền Giang",
    "Chợ nổi Cái Bè, Tiền Giang", "Chùa Vĩnh Tràng, Tiền Giang", "Cù lao Thới Sơn, Bến Tre"
]

# Tập dữ liệu ghi chú chuyến đi
NOTES_SAMPLES = [
    "", # Chuỗi rỗng cho các trường hợp không để lại ghi chú
    # Nhóm 1: Nhu cầu cá nhân & Thư giãn
    "Đi dạo cuối tuần giải stress", "Tránh nóng Sài Gòn", "Chạy trốn deadline", 
    "Đi dạo ngắm phố phường", "Thư giãn sau giờ làm", "Chuyến đi chữa lành (Healing trip)",
    "Đổi gió thay đổi không khí", "Đi loanh quanh không mục đích", "Tìm không gian yên tĩnh đọc sách",
    
    # Nhóm 2: Nhu cầu xã hội & Gắn kết
    "Hẹn hò cafe cùng bạn bè", "Đưa đón người thân", "Hẹn hò lãng mạn", 
    "Tụ tập ăn uống cùng gia đình", "Đi picnic cuối tuần", "Thăm hỏi họ hàng", 
    "Giao lưu cùng đồng nghiệp", "Tổ chức tiệc/sinh nhật ngoài trời", 
    
    # Nhóm 3: Trải nghiệm & Khám phá
    "Chụp ảnh sống ảo", "Chuyến đi phượt ngắn", "Đi ăn uống khám phá ẩm thực", 
    "Săn mây sáng sớm", "Săn hoàng hôn/bình minh", "Cắm trại qua đêm", 
    "Trải nghiệm quán cafe mới mở", "Đi xem show âm nhạc", "Tham quan triển lãm nghệ thuật", 
    "Tham gia sự kiện văn hóa", "Đi lễ chùa/nhà thờ cầu bình an",
    
    # Nhóm 4: Công việc & Nhu cầu thực tế
    "Đi công tác ngắn ngày", "Gặp gỡ đối tác/khách hàng", "Tham gia hội thảo/event", 
    "Khảo sát thị trường", "Đi mua sắm cuối tuần", "Đi siêu thị mua đồ dự trữ", 
    "Chuyển đồ đạc nhẹ", "Đưa đón khách VIP ra sân bay"
]
def generate_trips_csv(filename="./SampleData/trips.csv", total_trips=1000, total_users=200):
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        
        # Đã sửa updated_at thành last_updated_at theo DB
        writer.writerow([
            'trip_id', 'user_id', 'title', 'origin_name', 'destination_name', 
            'start_time', 'end_time', 'total_estimated_budget', 
            'created_at', 'last_updated_at'
        ])

        for trip_idx in range(1, total_trips + 1):
            # Định dạng ID 10 ký tự
            trip_id = f"TRP_{trip_idx:06d}"
            user_id = f"USR_{random.randint(1, total_users):06d}"

            if random.random() < 0.85:
                origin_name, destination_name = random.sample(HCMC_LOCATIONS, 2)
            else:
                if random.choice([True, False]):
                    origin_name = random.choice(HCMC_LOCATIONS)
                    destination_name = random.choice(OTHER_LOCATIONS)
                else:
                    origin_name = random.choice(OTHER_LOCATIONS)
                    destination_name = random.choice(HCMC_LOCATIONS)

            title_templates = [
                f"Chuyến đi đến {destination_name.split(',')[0]}",
                f"Vi vu {destination_name.split(',')[0]}",
                f"Từ {origin_name.split(',')[0]} qua {destination_name.split(',')[0]}"
            ]
            title = random.choice(title_templates)

            start_time = fake.date_time_between(start_date='-1y', end_date='now')
            duration_minutes = random.randint(5, 180)
            end_time = start_time + timedelta(minutes=duration_minutes)

            budget = random.randint(2, 200) * 10000 
            total_estimated_budget = f"{budget:.2f}"
            
            created_at = start_time - timedelta(days=random.randint(0, 5))
            updated_at = created_at + timedelta(days=random.randint(0, 2)) if random.random() > 0.5 else created_at

            fmt = '%Y-%m-%d %H:%M:%S+07'
            writer.writerow([
                trip_id, user_id, title, origin_name, destination_name,
                start_time.strftime(fmt), end_time.strftime(fmt), total_estimated_budget,
                created_at.strftime(fmt), updated_at.strftime(fmt)
            ])

    print(f"✅ Đã tạo thành công {total_trips} chuyến đi! File: {filename}")

if __name__ == "__main__":
    import os
    os.makedirs("./SampleData", exist_ok=True)
    generate_trips_csv("./SampleData/trips.csv", 3000, 1000)