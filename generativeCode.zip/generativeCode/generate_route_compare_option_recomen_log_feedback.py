import csv
import random
import os
from datetime import datetime, timedelta

# --- CẤU HÌNH ĐƯỜNG DẪN TƯƠNG ĐỐI ---
BASE_DIR = "./SampleData/"
# Tùy thuộc vào tên file bạn đã chạy ở script trước, thường là trips_hcm_data.csv hoặc trips.csv
TRIPS_FILE = os.path.join(BASE_DIR, "trips.csv") 

PROVIDERS_FILE = os.path.join(BASE_DIR, "transport_providers.csv")
MODES_FILE = os.path.join(BASE_DIR, "transport_modes.csv")
COMP_FILE = os.path.join(BASE_DIR, "route_comparisons.csv")
OPTIONS_FILE = os.path.join(BASE_DIR, "route_options.csv")

# ==========================================
# 1. DỮ LIỆU TỪ ĐIỂN (LOOKUP TABLES)
# ==========================================
PROVIDERS_DATA = [
    {"name": "Grab", "type": "RIDE_HAILING", "api": True, "url": "grab.com/vn"},
    {"name": "Be", "type": "RIDE_HAILING", "api": True, "url": "be.com.vn"},
    {"name": "Gojek", "type": "RIDE_HAILING", "api": True, "url": "gojek.com/vn"},
    {"name": "Xanh SM", "type": "RIDE_HAILING", "api": True, "url": "xanhsm.com"},
    {"name": "Trung tâm QLGTCC TPHCM", "type": "PUBLIC_TRANSPORT", "api": False, "url": "buyttphcm.com.vn"},
    {"name": "Saigon Metro", "type": "PUBLIC_TRANSPORT", "api": False, "url": "maur.hochiminhcity.gov.vn"},
    {"name": "Vinasun Taxi", "type": "RIDE_HAILING", "api": False, "url": "vinasun.vn"},
    {"name": "Thuê xe máy Sài Gòn", "type": "PARTNER_RENTAL", "api": False, "url": ""}
]

MODES_DATA = [
    {"code": "BUS", "name": "Xe buýt"},
    {"code": "METRO", "name": "Tàu điện ngầm"},
    {"code": "TRAIN", "name": "Tàu hỏa"},
    {"code": "WALK", "name": "Đi bộ"},
    {"code": "BIKE", "name": "Xe đạp/Xe máy"},
    {"code": "CAR", "name": "Ô tô cá nhân"},
    {"code": "RIDE_HAILING", "name": "Xe ôm/Taxi công nghệ"}
]

def format_id(prefix, num):
    """
    Đảm bảo ID luôn đúng 10 ký tự theo chuẩn character(10) của SQL.
    Ví dụ: PRV_000001, MOD_000001, CMP_000001
    """
    return f"{prefix}_{num:06d}"

def generate_all_data():
    os.makedirs(BASE_DIR, exist_ok=True)
    fmt = '%Y-%m-%d %H:%M:%S+07'
    now_str = datetime.now().strftime(fmt)

    # --- BƯỚC 1: TẠO BẢNG PROVIDERS VÀ MODES ---
    providers_db = {} # Phân loại để chọn ngẫu nhiên
    with open(PROVIDERS_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['provider_id', 'name', 'provider_type', 'api_supported', 'website_url', 'is_active', 'created_at', 'last_updated_at'])
        for idx, p in enumerate(PROVIDERS_DATA, 1):
            p_id = format_id("PRV", idx)
            writer.writerow([p_id, p['name'], p['type'], p['api'], p['url'], True, now_str, now_str])
            providers_db[p['type']] = providers_db.get(p['type'], []) + [p_id]

    modes_db = {} 
    with open(MODES_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['mode_id', 'code', 'name', 'created_at', 'last_updated_at'])
        for idx, m in enumerate(MODES_DATA, 1):
            m_id = format_id("MOD", idx)
            writer.writerow([m_id, m['code'], m['name'], now_str, now_str])
            modes_db[m['code']] = m_id

    print("✅ Đã tạo chuẩn schema cho transport_providers và transport_modes.")

    # --- BƯỚC 2: ĐỌC DỮ LIỆU TRIPS (ĐỒNG BỘ CONTEXT) ---
    if not os.path.exists(TRIPS_FILE):
        print(f"❌ Không tìm thấy {TRIPS_FILE}. Hãy kiểm tra lại tên file (trips_hcm_data.csv hay trips.csv).")
        return

    trips = []
    with open(TRIPS_FILE, mode='r', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            # Lấy thời gian xuất phát làm chuẩn để tính thời gian "tra đường" (requested_at)
            start_time_field = row.get('start_time') or row.get('created_at')
            trips.append({
                'trip_id': row['trip_id'], # ID giữ nguyên từ bảng cũ để làm Foreign Key
                'user_id': row['user_id'],
                'origin': row['origin_name'],
                'dest': row['destination_name'],
                'time': datetime.strptime(start_time_field, fmt)
            })

    # --- BƯỚC 3: TẠO BẢNG ROUTE COMPARISONS & OPTIONS ---
    with open(COMP_FILE, 'w', newline='', encoding='utf-8') as f_comp, \
         open(OPTIONS_FILE, 'w', newline='', encoding='utf-8') as f_opt:
        
        comp_writer = csv.writer(f_comp)
        opt_writer = csv.writer(f_opt)
        
        # Header chuẩn Schema SQL
        comp_writer.writerow([
            'comparison_id', 'user_id', 'trip_id', 'origin_name', 'destination_name', 
            'origin_latitude', 'origin_longitude', 'destination_latitude', 'destination_longitude', 
            'requested_at', 'last_updated_at'
        ])
        
        opt_writer.writerow([
            'option_id', 'comparison_id', 'provider_id', 'mode_id', 'option_name', 
            'estimated_cost', 'currency', 'estimated_duration_min', 'distance_km', 
            'transfer_count', 'retrieved_at', 'last_updated_at'
        ])

        comp_idx = 1; opt_idx = 1
        
        # Chọn ngẫu nhiên khoảng 500 chuyến đi để giả lập người dùng tra cứu bản đồ
        selected_trips = random.sample(trips, min(500, len(trips)))
        
        for trip in selected_trips:
            # Thời điểm tra đường thường diễn ra trước khi xuất phát 10 - 1440 phút (1 ngày)
            req_time = trip['time'] - timedelta(minutes=random.randint(10, 1440))
            req_time_str = req_time.strftime(fmt)
            
            comp_id = format_id("CMP", comp_idx)
            
            comp_writer.writerow([
                comp_id, trip['user_id'], trip['trip_id'], trip['origin'], trip['dest'],
                round(random.uniform(10.7, 10.85), 7), round(random.uniform(106.6, 106.8), 7), 
                round(random.uniform(10.7, 10.85), 7), round(random.uniform(106.6, 106.8), 7), 
                req_time_str, req_time_str # requested_at và last_updated_at
            ])

            distance = round(random.uniform(1.0, 25.0), 2)
            
            # --- Option 1: Xe ôm công nghệ (Grab/Be/Gojek...) ---
            opt_id = format_id("OPT", opt_idx)
            provider_rh = random.choice(providers_db['RIDE_HAILING'])
            opt_writer.writerow([
                opt_id, comp_id, provider_rh, modes_db['RIDE_HAILING'], "Xe ôm công nghệ (Bike)",
                round(distance * 6000), 'VND', int(distance * 3), distance, 0, 
                req_time_str, req_time_str
            ])
            opt_idx += 1

            # --- Option 2: Ô tô công nghệ ---
            opt_id = format_id("OPT", opt_idx)
            opt_writer.writerow([
                opt_id, comp_id, provider_rh, modes_db['RIDE_HAILING'], "Ô tô công nghệ (Car)",
                round(distance * 13000), 'VND', int(distance * 4), distance, 0, 
                req_time_str, req_time_str
            ])
            opt_idx += 1

            # --- Option 3: Xe buýt (Chỉ gợi ý nếu đi xa trên 3km) ---
            if distance > 3.0: 
                opt_id = format_id("OPT", opt_idx)
                provider_pt = providers_db['PUBLIC_TRANSPORT'][0]
                opt_writer.writerow([
                    opt_id, comp_id, provider_pt, modes_db['BUS'], "Tuyến xe buýt nội đô",
                    7000, 'VND', int(distance * 7), distance, random.randint(0, 1), 
                    req_time_str, req_time_str
                ])
                opt_idx += 1
                
            # --- Option 4: Đi bộ (Chỉ gợi ý nếu rất gần <= 2km) ---
            if distance <= 2.0: 
                opt_id = format_id("OPT", opt_idx)
                opt_writer.writerow([
                    opt_id, comp_id, "", modes_db['WALK'], "Đi bộ", # Provider rỗng
                    0, 'VND', int(distance * 15), distance, 0, 
                    req_time_str, req_time_str
                ])
                opt_idx += 1

            comp_idx += 1

    print(f"✅ Đã tạo bảng route_comparisons ({comp_idx - 1} dòng) và route_options ({opt_idx - 1} dòng) chuẩn SQL.")

if __name__ == "__main__":
    generate_all_data()