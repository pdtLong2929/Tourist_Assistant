import csv
import random
import os
from datetime import datetime, timedelta
from faker import Faker
from datetime import datetime, timedelta

fake = Faker('vi_VN')
# 1. DANH SÁCH ĐỊA ĐIỂM
HCMC_LOCATIONS = [
    "Chợ Bến Thành, Quận 1", "Phố đi bộ Nguyễn Huệ, Quận 1", "Landmark 81, Bình Thạnh",
    "Nhà thờ Đức Bà, Quận 1", "Bưu điện Trung tâm Sài Gòn", "Dinh Độc Lập, Quận 1",
    "Bitexco Financial Tower, Quận 1", "Bến Bạch Đằng, Quận 1", "Hồ Con Rùa, Quận 3",
    "Phố Tây Bùi Viện, Quận 1", "Bảo tàng Chứng tích Chiến tranh, Quận 3", "Bảo tàng Mỹ thuật TP.HCM",
    "Crescent Mall, Quận 7", "Hồ Bán Nguyệt, Quận 7", "SC VivoCity, Quận 7",
    "Takashimaya, Quận 1", "Vincom Center Đồng Khởi", "Vạn Hạnh Mall, Quận 10",
    "Aeon Mall Tân Phú", "Aeon Mall Bình Tân", "Giga Mall, TP. Thủ Đức", "Estella Place, TP. Thủ Đức",
    "Khu du lịch Suối Tiên, TP. Thủ Đức", "Công viên Đầm Sen, Quận 11", "Thảo Cầm Viên, Quận 1",
    "Khu du lịch Bình Quới, Bình Thạnh", "Khu du lịch Văn Thánh, Bình Thạnh",
    "Chợ Lớn (Chợ Bình Tây), Quận 5", "Chợ An Đông, Quận 5", "Chợ Tân Định, Quận 1",
    "Chợ Bà Chiểu, Bình Thạnh", "Chợ Hạnh Thông Tây, Gò Vấp", "Phố ẩm thực Phan Xích Long, Phú Nhuận",
    "Khu Tên Lửa, Bình Tân", "Phố lẩu dê Hồ Thị Kỷ, Quận 10", "Chợ hoa Hồ Thị Kỷ",
    "Trường Đại học Khoa học Tự nhiên, Quận 5", "Trường Đại học Khoa học Tự nhiên - Cơ sở Linh Trung", 
    "Làng Đại học Quốc gia, TP. Thủ Đức", "Đại học Bách Khoa TP.HCM, Quận 10",
    "Đại học RMIT, Quận 7", "Đại học Tôn Đức Thắng, Quận 7", "Đại học Kinh tế TP.HCM, Quận 3",
    "Đại học Ngoại thương Cơ sở 2, Bình Thạnh", "Hutech, Bình Thạnh",
    "Sân bay Tân Sơn Nhất, Tân Bình", "Bến xe Miền Đông (Mới), TP. Thủ Đức", 
    "Bến xe Miền Tây, Bình Tân", "Ga Sài Gòn, Quận 3", "Bến xe An Sương, Hóc Môn",
    "Bệnh viện Chợ Rẫy, Quận 5", "Bệnh viện Đại học Y Dược, Quận 5", 
    "Bệnh viện Nhi Đồng 1, Quận 10", "Bệnh viện Từ Dũ, Quận 1",
    "Công viên Lê Văn Tám, Quận 1", "Công viên Hoàng Văn Thụ, Tân Bình", 
    "Công viên Gia Định, Gò Vấp", "Chùa Ngọc Hoàng, Quận 1", "Chùa Bửu Long, TP. Thủ Đức",
    "Việt Nam Quốc Tự, Quận 10", "Chùa Vĩnh Nghiêm, Quận 3"
]

OTHER_LOCATIONS = [
    "Ga Dĩ An, Bình Dương", "Khu công nghiệp Sóng Thần, Dĩ An", "Khu du lịch Thủy Châu, Dĩ An",
    "Aeon Mall Bình Dương Canary", "Làng tre Phú An, Bình Dương", "Khu du lịch Đại Nam, Bình Dương", 
    "Chùa Bà Thiên Hậu, Thủ Dầu Một", "Hồ Đá, Dĩ An",
    "Khu du lịch Bửu Long, Đồng Nai", "Thác Giang Điền, Đồng Nai", "Hồ Trị An, Đồng Nai",
    "Vườn quốc gia Cát Tiên, Đồng Nai", "Vườn ca cao Trọng Đức, Định Quán",
    "Bãi Sau, TP. Vũng Tàu", "Bãi Trước, TP. Vũng Tàu", "Tượng Chúa Dang Tay, Vũng Tàu",
    "Mũi Nghinh Phong, Vũng Tàu", "Ngọn hải đăng Vũng Tàu", "Hồ Tràm, Bà Rịa - Vũng Tàu",
    "Biển Long Hải, Bà Rịa", "Đảo Long Sơn, Bà Rịa",
    "Núi Bà Đen, Tây Ninh", "Toà thánh Tây Ninh", "Hồ Dầu Tiếng, Tây Ninh", 
    "Cửa khẩu Mộc Bài, Tây Ninh", "Địa đạo Củ Chi, TP.HCM", "Biển Cần Giờ, TP.HCM",
    "Đảo Khỉ Cần Giờ, TP.HCM",
    "Làng nổi Tân Lập, Long An", "Cánh đồng bất tận, Long An", "Bến Ninh Kiều, Cần Thơ", 
    "Chợ nổi Cái Răng, Cần Thơ", "Cồn Thới Sơn, Tiền Giang", "Trại rắn Đồng Tâm, Tiền Giang",
    "Chợ nổi Cái Bè, Tiền Giang", "Chùa Vĩnh Tràng, Tiền Giang", "Cù lao Thới Sơn, Bến Tre"
]

ALL_LOCATIONS = HCMC_LOCATIONS + OTHER_LOCATIONS

# 2. TỪ ĐIỂN GHI CHÚ
NOTES_DICTIONARY = {
    "tam_linh": ["Thắp nhang cầu bình an", "Vãn cảnh chùa", "Mặc đồ lịch sự", "Tìm không gian thanh tịnh", "Đi lễ dịp rằm/mùng 1"],
    "giao_duc": ["Họp nhóm làm đồ án", "Đợi bạn học xong", "Lên thư viện mượn sách", "Tham gia hội thảo CLB", "Nộp hồ sơ/giấy tờ"],
    "mua_sam": ["Đi siêu thị sắm đồ", "Săn sale", "Ghé mua quà lưu niệm", "Tranh thủ lượn lờ window-shopping", "Ăn uống ở Foodcourt"],
    "du_lich_song_ao": ["Check-in sống ảo cực đẹp", "Ngắm cảnh hoàng hôn", "Chụp bộ ảnh kỷ niệm", "Thuê đồ chụp hình", "Góc này view rất chill"],
    "y_te": ["Khám tổng quát", "Thăm người nhà", "Lấy kết quả xét nghiệm", "Mua thuốc", "Tái khám theo lịch"],
    "giao_thong": ["Đón người thân", "Gửi hàng hóa", "Chờ lấy vé", "Đợi xe trung chuyển"],
    "an_uong": ["Review quán mới mở", "Hẹn hò ăn tối", "Thưởng thức đặc sản", "Ăn nhậu cùng hội bạn", "Chỉ mua mang về (Takeaway)"],
    "chung": ["Ghé ngang qua", "Điểm dừng chân nghỉ ngơi", "Hẹn gặp mặt ở đây", "Ghé trú mưa/tránh nắng"]
}

def analyze_category(name):
    """Hàm tự động phân loại địa điểm dựa trên từ khóa trong tên"""
    n = name.lower()
    if any(kw in n for kw in ["chùa", "nhà thờ", "toà thánh", "quốc tự", "đức bà"]): return "tam_linh"
    if any(kw in n for kw in ["đại học", "rmit", "hutech"]): return "giao_duc"
    if "bệnh viện" in n: return "y_te"
    if any(kw in n for kw in ["sân bay", "bến xe", "ga ", "cửa khẩu"]): return "giao_thong"
    if any(kw in n for kw in ["chợ", "mall", "vincom", "takashimaya"]): return "mua_sam"
    if any(kw in n for kw in ["ẩm thực", "lẩu dê"]): return "an_uong"
    return "du_lich_song_ao"


def generate_both_csvs(
    input_trip_file="./SampleData/trips.csv",
    destinations_file="./SampleData/destinations.csv",
    trip_dests_file="./SampleData/trip_destinations.csv"
):
    output_dir = os.path.dirname(trip_dests_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    # --- BƯỚC 1: TẠO BẢNG DESTINATIONS (Bổ sung đủ cột theo Schema DB) ---
    destinations_db = {}
    
    with open(destinations_file, mode='w', newline='', encoding='utf-8') as f_dest:
        writer = csv.writer(f_dest)
        # Bổ sung các cột bị thiếu so với DB
        writer.writerow([
            'destination_id', 'name', 'category', 'address', 'latitude', 'longitude', 
            'description', 'rating_avg', 'is_active', 'created_at', 'last_updated_at'
        ])
        
        for idx, location_name in enumerate(ALL_LOCATIONS, start=1):
            category = analyze_category(location_name)
            dest_id = f"DST_{idx:06d}" # ID 10 ký tự
            destinations_db[dest_id] = category 
            
            # Sinh dữ liệu ảo cho các trường còn lại
            address = f"{fake.street_address()}, TP. Hồ Chí Minh"
            lat, lng = round(random.uniform(10.3, 11.1), 6), round(random.uniform(106.3, 106.9), 6)
            rating = round(random.uniform(3.5, 5.0), 2)
            now_str = "2024-01-01 10:00:00+07"
            
            writer.writerow([
                dest_id, location_name, category, address, lat, lng, 
                f"Mô tả cho {location_name}", rating, True, now_str, now_str
            ])
            
    print(f"✅ Đã tạo bảng {destinations_file} với {len(ALL_LOCATIONS)} địa điểm.")

    # --- BƯỚC 2: TẠO BẢNG TRIP DESTINATIONS ---
    if not os.path.exists(input_trip_file):
        print(f"⚠️ Không tìm thấy file '{input_trip_file}'.")
        return

    with open(input_trip_file, mode='r', encoding='utf-8') as infile:
        trips_data = list(csv.DictReader(infile))

    with open(trip_dests_file, mode='w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(['trip_id', 'destination_id', 'visit_order', 'arrival_time', 'departure_time', 'note'])

        # Lấy danh sách ID 10 ký tự của destination
        all_dest_ids = list(destinations_db.keys())

        for trip in trips_data:
            fmt = '%Y-%m-%d %H:%M:%S+07'
            start_time = datetime.strptime(trip['start_time'], fmt)
            end_time = datetime.strptime(trip['end_time'], fmt)
            
            total_duration = int((end_time - start_time).total_seconds() / 60)
            
            if total_duration < 30: num_places = 1
            elif total_duration < 90: num_places = random.randint(1, 2)
            else: num_places = random.randint(2, 4)

            current_time = start_time
            dest_ids = random.sample(all_dest_ids, num_places)

            for order in range(1, num_places + 1):
                dest_id = dest_ids[order - 1]
                
                travel_time = random.randint(5, 15)
                arrival_time = current_time + timedelta(minutes=travel_time)
                if arrival_time >= end_time: break
                
                remaining_time = int((end_time - arrival_time).total_seconds() / 60)
                if order == num_places:
                    stay_duration = remaining_time - random.randint(0, 5) 
                else:
                    stay_duration = random.randint(10, max(15, remaining_time // (num_places - order + 1)))

                departure_time = arrival_time + timedelta(minutes=stay_duration)
                if departure_time > end_time: departure_time = end_time

                category = destinations_db[dest_id]
                note = random.choice(NOTES_DICTIONARY[category]) if random.random() < 0.8 else ""

                writer.writerow([
                    trip['trip_id'], dest_id, order, 
                    arrival_time.strftime(fmt), departure_time.strftime(fmt), note
                ])
                current_time = departure_time

    print(f"✅ Đã tạo thành công dữ liệu cho {trip_dests_file}.")

if __name__ == "__main__":
    generate_both_csvs()